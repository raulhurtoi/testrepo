//
//  OnfidoAnalyticsConfiguration.h
//  Onfido
//
//  Created by Gunduz, Kerem on 07/08/2019.
//

#import <Foundation/Foundation.h>

typedef NSMutableURLRequest *_Nonnull (^OnfidoRequestFactory)(NSURL *_Nonnull);

@interface OnfidoAnalyticsConfiguration : NSObject

@property (nonatomic, strong, nullable) OnfidoRequestFactory requestFactory;
@property (nonatomic, copy, readonly, nonnull) NSString * writeKey;

- (instancetype _Nonnull)initWithWriteKey:(NSString * _Nonnull) writeKey;

@end

