//
//  OnfidoBlurDetection.h
//  Onfido
//
//  Created by Anurag Ajwani on 29/10/2019.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface OnfidoBlurDetection: NSObject

- (BOOL) detect: (UIImage *) image;

@end
