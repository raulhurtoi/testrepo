//
//  GlareDetection.h
//  OpenCVTest
//
//  Created by Anurag Ajwani on 11/05/2017.
//  Copyright © 2017 onfido. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface GlareDetection : NSObject

- (BOOL) detect: (UIImage *) image;

@end
